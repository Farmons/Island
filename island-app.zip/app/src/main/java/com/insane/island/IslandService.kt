package com.insane.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.Rating
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class IslandService : Service() {

    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var compact: FrameLayout
    private lateinit var compactArt: ImageView
    private lateinit var eq: EqualizerView
    private lateinit var card: LinearLayout
    private lateinit var cardArt: ImageView
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var seek: SeekBar
    private lateinit var tCur: TextView
    private lateinit var tEnd: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var btnLike: ImageButton

    private val handler = Handler(Looper.getMainLooper())
    private var controller: MediaController? = null
    private var expanded = false
    private var liked = false
    private var dragging = false
    private var attached = false
    private var duration = 0L
    private var lastArt: Bitmap? = null

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyPrefs() }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { refresh() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { refresh() }
        override fun onSessionDestroyed() { handler.post { reload() } }
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            if (expanded) handler.postDelayed(this, 500)
        }
    }

    private val collapse = object : Runnable {
        override fun run() {
            if (dragging) handler.postDelayed(this, 2000) else setExpanded(false)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun View.round(r: Int) {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r.toFloat())
            }
        }
        clipToOutline = true
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%02d:%02d".format(s / 60, s % 60)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("island", Context.MODE_PRIVATE)
        buildViews()
        lp = WindowManager.LayoutParams(
            WRAP, WRAP,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }
        applyPrefs()
        root.visibility = View.GONE
        wm.addView(root, lp)
        attached = true
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        initSessions()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            msm.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {}
        controller?.unregisterCallback(cb)
        if (attached) wm.removeView(root)
        attached = false
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Остров", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "island")
            .setSmallIcon(R.drawable.ic_headphones)
            .setContentTitle("Остров работает")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun buildViews() {
        // ---------- компактная плашка ----------
        compact = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(19).toFloat()
                setStroke(dp(1), 0xFF2A2A2A.toInt())
            }
            layoutParams = FrameLayout.LayoutParams(dp(210), dp(38))
            setOnClickListener { setExpanded(true) }
        }
        compactArt = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            round(dp(8))
        }
        compact.addView(
            compactArt,
            FrameLayout.LayoutParams(dp(28), dp(28), Gravity.START or Gravity.CENTER_VERTICAL)
                .apply { leftMargin = dp(6) }
        )
        eq = EqualizerView(this)
        compact.addView(
            eq,
            FrameLayout.LayoutParams(dp(22), dp(18), Gravity.END or Gravity.CENTER_VERTICAL)
                .apply { rightMargin = dp(16) }
        )

        // ---------- раскрытая карточка ----------
        val screenW = resources.displayMetrics.widthPixels
        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(12))
            layoutParams = FrameLayout.LayoutParams(minOf(dp(360), screenW - dp(24)), WRAP)
            visibility = View.GONE
        }

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setOnClickListener { setExpanded(false) }
        }
        cardArt = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            round(dp(14))
        }
        head.addView(cardArt, LinearLayout.LayoutParams(dp(64), dp(64)))

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        title = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        artist = TextView(this).apply {
            setTextColor(0xB3FFFFFF.toInt())
            textSize = 16f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        texts.addView(title)
        texts.addView(artist)
        head.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })

        val hp = ImageView(this).apply {
            setImageResource(R.drawable.ic_headphones)
            setColorFilter(Color.WHITE)
        }
        head.addView(hp, LinearLayout.LayoutParams(dp(24), dp(24)).apply { gravity = Gravity.TOP })
        card.addView(head)

        // ---------- прогресс ----------
        val seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        tCur = TextView(this).apply { setTextColor(0x99FFFFFF.toInt()); textSize = 14f; text = "00:00" }
        tEnd = TextView(this).apply { setTextColor(0x99FFFFFF.toInt()); textSize = 14f; text = "00:00" }
        seek = SeekBar(this).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(Color.WHITE)
            progressBackgroundTintList = ColorStateList.valueOf(0x55FFFFFF)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            setPadding(dp(12), 0, dp(12), 0)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser && duration > 0) tCur.text = fmt(duration * p / 1000)
            }
            override fun onStartTrackingTouch(s: SeekBar) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar) {
                dragging = false
                if (duration > 0) controller?.transportControls?.seekTo(duration * s.progress / 1000)
            }
        })
        seekRow.addView(tCur)
        seekRow.addView(seek, LinearLayout.LayoutParams(0, dp(36), 1f))
        seekRow.addView(tEnd)
        card.addView(seekRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, WRAP)
            .apply { topMargin = dp(14) })

        // ---------- кнопки ----------
        val ctrl = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun button(res: Int, pad: Int, onClick: () -> Unit): ImageButton {
            val b = ImageButton(this).apply {
                setImageResource(res)
                setColorFilter(Color.WHITE)
                background = null
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
                setOnClickListener { onClick() }
            }
            ctrl.addView(b, LinearLayout.LayoutParams(0, dp(64), 1f))
            return b
        }
        // дизлайк = пропустить трек
        button(R.drawable.ic_dislike, 18) { controller?.transportControls?.skipToNext() }
        button(R.drawable.ic_prev, 16) { controller?.transportControls?.skipToPrevious() }
        btnPlay = button(R.drawable.ic_pause, 12) {
            val c = controller
            if (c?.playbackState?.state == PlaybackState.STATE_PLAYING) {
                c.transportControls.pause()
            } else {
                c?.transportControls?.play()
            }
        }
        button(R.drawable.ic_next, 16) { controller?.transportControls?.skipToNext() }
        btnLike = button(R.drawable.ic_heart, 18) {
            liked = !liked
            btnLike.setColorFilter(if (liked) 0xFFFF4D6A.toInt() else Color.WHITE)
            try {
                controller?.transportControls?.setRating(Rating.newHeartRating(liked))
            } catch (_: Exception) {}
        }
        card.addView(ctrl)

        root = FrameLayout(this)
        root.addView(compact)
        root.addView(card)
        applyColor(0xFFC8742F.toInt())
    }

    private fun applyPrefs() {
        lp.y = if (expanded) dp(10) else dp(prefs.getInt("y", 6))
        compact.layoutParams = compact.layoutParams.apply { width = dp(prefs.getInt("w", 210)) }
        if (attached) wm.updateViewLayout(root, lp)
    }

    private fun setExpanded(v: Boolean) {
        expanded = v
        handler.removeCallbacks(collapse)
        handler.removeCallbacks(ticker)
        if (v) {
            compact.visibility = View.GONE
            card.visibility = View.VISIBLE
            card.alpha = 0f
            card.translationY = -dp(20).toFloat()
            card.animate().alpha(1f).translationY(0f).setDuration(220).start()
            handler.postDelayed(collapse, 7000)
            handler.post(ticker)
        } else {
            card.visibility = View.GONE
            compact.visibility = View.VISIBLE
        }
        applyPrefs()
    }

    private fun hide() {
        if (expanded) setExpanded(false)
        root.visibility = View.GONE
    }

    // ---------- музыка ----------
    private fun initSessions() {
        try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val cn = ComponentName(this, MediaListener::class.java)
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            pick(msm.getActiveSessions(cn))
        } catch (e: SecurityException) {
            // нет доступа к уведомлениям — пробуем снова через 3 секунды
            handler.postDelayed({ initSessions() }, 3000)
        }
    }

    private fun reload() {
        try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            pick(msm.getActiveSessions(ComponentName(this, MediaListener::class.java)))
        } catch (_: SecurityException) {}
    }

    private fun pick(list: List<MediaController>?) {
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        if (best?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(cb)
            controller = best
            best?.registerCallback(cb, handler)
            liked = false
            btnLike.setColorFilter(Color.WHITE)
        }
        refresh()
    }

    private fun refresh() {
        val c = controller
        val md = c?.metadata
        val st = c?.playbackState
        if (c == null || md == null || st == null ||
            st.state == PlaybackState.STATE_STOPPED || st.state == PlaybackState.STATE_NONE
        ) {
            hide()
            return
        }
        title.text = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        artist.text = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        duration = md.getLong(MediaMetadata.METADATA_KEY_DURATION)

        val art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (art != null && art !== lastArt) {
            lastArt = art
            compactArt.setImageBitmap(art)
            cardArt.setImageBitmap(art)
            applyColor(Bitmap.createScaledBitmap(art, 1, 1, true).getPixel(0, 0))
        }

        val playing = st.state == PlaybackState.STATE_PLAYING
        eq.playing = playing
        btnPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        root.visibility = View.VISIBLE
        updateProgress()
    }

    private fun updateProgress() {
        val st = controller?.playbackState ?: return
        var pos = st.position
        if (st.state == PlaybackState.STATE_PLAYING) {
            pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        }
        if (duration > 0) pos = pos.coerceIn(0L, duration)
        tCur.text = fmt(pos)
        tEnd.text = fmt(duration)
        if (!dragging) seek.progress = if (duration > 0) (pos * 1000 / duration).toInt() else 0
    }

    private fun applyColor(base: Int) {
        val hsv = FloatArray(3)
        Color.colorToHSV(base, hsv)
        hsv[1] = (hsv[1] * 1.15f).coerceAtMost(1f)
        hsv[2] = hsv[2].coerceIn(0.55f, 0.95f)
        val main = Color.HSVToColor(hsv)
        val dark = Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], 0.12f))
        card.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(dark, dark, main)
        ).apply { cornerRadius = dp(36).toFloat() }
        hsv[2] = 1f
        hsv[1] = (hsv[1] * 0.8f)
        eq.color = Color.HSVToColor(hsv)
    }
}
