package com.insane.island

import android.service.notification.NotificationListenerService

// Пустой сервис: нужен только чтобы Android дал доступ к медиа-сессиям (музыке).
class MediaListener : NotificationListenerService()
