package com.insane.island

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.session.MediaSessionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val BG = 0xFF08080C.toInt()
    private val CARD = 0xFF14111D.toInt()
    private val STROKE = 0xFF2B2145.toInt()
    private val PURPLE = 0xFF8B5CF6.toInt()
    private val PURPLE2 = 0xFFA855F7.toInt()
    private val LIGHT = 0xFFC4B5FD.toInt()
    private val MUTED = 0xFF9A93B5.toInt()
    private val GREEN = 0xFF34D399.toInt()
    private val RED = 0xFFF87171.toInt()
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

    private var density = 1f
    private lateinit var dot1: View
    private lateinit var dot2: View
    private lateinit var st1: TextView
    private lateinit var st2: TextView
    private lateinit var diag: TextView

    private fun dp(v: Int) = (v * density).toInt()

    private fun shape(color: Int, radius: Int, strokeColor: Int = 0, strokeW: Int = 0) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (strokeW > 0) setStroke(dp(strokeW), strokeColor)
        }

    private fun lp(top: Int = 0) =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(CARD, 22, STROKE, 1)
        setPadding(dp(18), dp(16), dp(18), dp(16))
    }

    // kind: 0 = залитая фиолетовая, 1 = с фиолетовой рамкой, 2 = тёмная
    private fun button(t: String, kind: Int, onClick: () -> Unit): TextView {
        val base: GradientDrawable = when (kind) {
            0 -> GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(PURPLE, PURPLE2))
                .apply { cornerRadius = dp(16).toFloat() }
            1 -> shape(0x00000000, 16, PURPLE, 1)
            else -> shape(0xFF1C1829.toInt(), 16, STROKE, 1)
        }
        return TextView(this).apply {
            text = t
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), base, null)
            isClickable = true
            setOnClickListener { onClick() }
        }
    }

    private fun statusRow(title: String): Triple<LinearLayout, View, TextView> {
        val dot = View(this)
        val st = TextView(this).apply { textSize = 14f }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(12) })
            addView(label(title, 16f, Color.WHITE), LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(st)
        }
        return Triple(row, dot, st)
    }

    private fun setStatus(dot: View, st: TextView, ok: Boolean) {
        dot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (ok) GREEN else RED)
        }
        st.text = if (ok) "включено" else "выключено"
        st.setTextColor(if (ok) GREEN else RED)
    }

    private fun pairRow(a: TextView, b: TextView) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
        addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(6) })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        density = resources.displayMetrics.density
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.setBackgroundColor(BG)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(44), dp(20), dp(28))
        }

        // ---------- шапка ----------
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher_fg)
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, dp(22).toFloat())
                }
            }
            clipToOutline = true
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("Остров", 32f, Color.WHITE, true))
            addView(label("Музыкальный остров у камеры", 14f, LIGHT))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(logo, LinearLayout.LayoutParams(dp(72), dp(72)))
            addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(16) })
        }
        col.addView(header)

        // ---------- состояние ----------
        val c1 = card()
        c1.addView(label("СОСТОЯНИЕ", 12f, MUTED, true))
        val r1 = statusRow("Поверх других окон")
        val r2 = statusRow("Доступ к уведомлениям")
        dot1 = r1.second; st1 = r1.third
        dot2 = r2.second; st2 = r2.third
        c1.addView(r1.first, lp(14))
        c1.addView(r2.first, lp(14))
        col.addView(c1, lp(28))

        // ---------- настройка ----------
        col.addView(label("НАСТРОЙКА", 12f, MUTED, true), lp(26))
        col.addView(button("1   Разрешить поверх окон", 1) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, lp(10))
        col.addView(button("2   Доступ к уведомлениям", 1) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }, lp(10))
        col.addView(button("Включить остров", 0) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала шаг 1", Toast.LENGTH_SHORT).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this, IslandService::class.java))
            }
        }, lp(18))
        col.addView(button("Выключить остров", 2) {
            stopService(Intent(this, IslandService::class.java))
        }, lp(10))

        // ---------- положение ----------
        val c2 = card()
        c2.addView(label("Положение под камеру", 16f, Color.WHITE, true))
        c2.addView(
            pairRow(button("▲  Выше", 2) { change("y", -2, -10, 80) }, button("▼  Ниже", 2) { change("y", 2, -10, 80) }),
            lp(14)
        )
        c2.addView(
            pairRow(button("◀  Уже", 2) { change("w", -10, 80, 320) }, button("Шире  ▶", 2) { change("w", 10, 80, 320) }),
            lp(10)
        )
        col.addView(c2, lp(26))

        // ---------- диагностика ----------
        col.addView(button("Диагностика плеера", 2) {
            diag.text = collectDiag()
            diag.visibility = View.VISIBLE
        }, lp(26))
        diag = TextView(this).apply {
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTextColor(LIGHT)
            setTextIsSelectable(true)
            background = shape(CARD, 16, STROKE, 1)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            visibility = View.GONE
        }
        col.addView(diag, lp(10))

        col.addView(
            label("Чтобы остров не пропадал: Настройки → Батарея → Остров → «Без ограничений» и включи автозапуск.", 13f, MUTED),
            lp(22)
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(col)
        })
    }

    private fun collectDiag(): String {
        return try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
            if (list.isEmpty()) return "Нет активных плееров. Включи музыку и нажми ещё раз."
            list.joinToString("\n\n") { c ->
                val ca = c.playbackState?.customActions?.joinToString { "${it.action} / ${it.name}" } ?: "-"
                val na = MediaListener.acts.filterKeys { it.startsWith(c.packageName + "/") }
                    .values.flatten().joinToString { it.title?.toString() ?: "?" }
                "Плеер: ${c.packageName}\nКнопки сессии: $ca\nКнопки уведомления: $na"
            }
        } catch (e: SecurityException) {
            "Нет доступа к уведомлениям (шаг 2)."
        }
    }

    private fun change(key: String, delta: Int, min: Int, max: Int) {
        val p = getSharedPreferences("island", Context.MODE_PRIVATE)
        val def = if (key == "y") 6 else 140
        p.edit().putInt(key, (p.getInt(key, def) + delta).coerceIn(min, max)).apply()
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val ls = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        setStatus(dot1, st1, ov)
        setStatus(dot2, st2, ls)
    }
}
