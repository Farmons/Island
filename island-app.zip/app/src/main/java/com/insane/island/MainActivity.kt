package com.insane.island

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        fun btn(t: String, onClick: () -> Unit) {
            col.addView(Button(this).apply {
                text = t
                isAllCaps = false
                setOnClickListener { onClick() }
            })
        }

        col.addView(TextView(this).apply { text = "Остров"; textSize = 28f })
        status = TextView(this).apply { textSize = 16f; setPadding(0, dp(12), 0, dp(12)) }
        col.addView(status)

        btn("1. Разрешить поверх других окон") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Доступ к уведомлениям (для музыки)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn("3. Включить остров") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала шаг 1", Toast.LENGTH_SHORT).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this, IslandService::class.java))
            }
        }
        btn("Выключить остров") { stopService(Intent(this, IslandService::class.java)) }

        col.addView(TextView(this).apply {
            text = "\nПоложение под камеру:"
            textSize = 16f
        })
        btn("Выше") { change("y", -2, -10, 80) }
        btn("Ниже") { change("y", 2, -10, 80) }
        btn("Уже") { change("w", -10, 120, 320) }
        btn("Шире") { change("w", 10, 120, 320) }

        col.addView(TextView(this).apply {
            text = "\nЧтобы остров не пропадал: Настройки → Батарея → Остров → «Без ограничений», и включи автозапуск."
            textSize = 14f
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun change(key: String, delta: Int, min: Int, max: Int) {
        val p = getSharedPreferences("island", Context.MODE_PRIVATE)
        val def = if (key == "y") 6 else 210
        p.edit().putInt(key, (p.getInt(key, def) + delta).coerceIn(min, max)).apply()
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val ls = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        status.text = "Поверх окон: ${if (ov) "✅" else "❌"}\nДоступ к уведомлениям: ${if (ls) "✅" else "❌"}"
    }
}
